# DoorDash SMB Call Workspace

GitHub Pages subfolder package.

Upload the entire `smb-call-workspace` folder to your repository. The tool will live at:

`https://<username>.github.io/<repository-name>/smb-call-workspace/`

Example using the live DoorDash-Tools repo format:

`https://saulchavez-dd171997.github.io/DoorDash-Tools/smb-call-workspace/`

This avoids replacing the existing root `index.html`.
